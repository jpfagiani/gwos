param([Parameter(Mandatory=$true)][uri]$Portal)
$ErrorActionPreference = 'Stop'
if ($Portal.Scheme -ne 'https' -or $Portal.AbsolutePath -ne '/acesso' -or $Portal.Query -or $Portal.Fragment -or $Portal.UserInfo) {
    throw 'Informe a URL HTTPS do portal terminada em /acesso.'
}
$chave = Read-Host 'Chave fornecida pelo administrador do GWOS' -AsSecureString
$credencial = New-Object Management.Automation.PSCredential('gwos', $chave)
if ($credencial.GetNetworkCredential().Password -cnotmatch '^[a-f0-9]{64}$') { throw 'Chave invalida.' }
$destino = Join-Path $env:LOCALAPPDATA 'GWOS'
New-Item -ItemType Directory -Path $destino -Force | Out-Null
$script = Join-Path $destino 'GWOS-Monitor.ps1'
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'GWOS-Monitor.ps1') -Destination $script -Force
$credencial | Export-Clixml -LiteralPath (Join-Path $destino 'monitor.xml') -Force
$exe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$argumentos = '-NoProfile -WindowStyle Hidden -File "' + $script + '" -Portal "' + $Portal.AbsoluteUri + '"'
$shell = New-Object -ComObject WScript.Shell
$inicio = [Environment]::GetFolderPath('Startup')
$atalho = $shell.CreateShortcut((Join-Path $inicio 'GWOS Monitor.lnk'))
$atalho.TargetPath = $exe
$atalho.Arguments = $argumentos
$atalho.WorkingDirectory = $destino
$atalho.Save()
Write-Output 'Monitor configurado. Saia da sessao do Windows e entre novamente para inicia-lo.'
