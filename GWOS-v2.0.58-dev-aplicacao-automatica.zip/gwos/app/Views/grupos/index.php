<?php $titulo = 'Grupos & IPs'; $modulo = 'grupos'; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0 fw-bold">Grupos de IPs</h5>
    <div class="d-flex gap-2">
        <button class="btn btn-sm btn-outline-secondary" onclick="aplicarNftables()">
            <i class="bi bi-play-fill me-1"></i>Aplicar nftables
        </button>
        <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#modalGrupo">
            <i class="bi bi-plus-lg me-1"></i>Novo Grupo
        </button>
    </div>
</div>

<div class="card border-0 shadow-sm mb-4">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Nome</th>
                    <th>Tipo</th>
                    <th>Descrição</th>
                    <th class="text-center">IPs</th>
                    <th class="text-end">Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($grupos)): ?>
                    <tr><td colspan="5" class="text-center text-muted py-3">Nenhum grupo cadastrado.</td></tr>
                <?php else: ?>
                    <?php
                    $cores = ['bloqueado' => 'danger', 'parcial' => 'warning', 'liberado' => 'success', 'isento' => 'info'];
                    foreach ($grupos as $g): ?>
                        <tr>
                            <td class="fw-semibold"><?= h($g['nome']) ?></td>
                            <td>
                                <span class="badge bg-<?= $cores[$g['tipo']] ?? 'secondary' ?>">
                                    <?= h(ucfirst($g['tipo'])) ?>
                                </span>
                            </td>
                            <td class="text-muted small"><?= h($g['descricao'] ?? '') ?></td>
                            <td class="text-center">
                                <button id="btn-ips-<?= $g['id'] ?>" class="btn btn-sm btn-outline-primary" onclick="verIps(<?= $g['id'] ?>, '<?= h($g['nome']) ?>')">
                                    <i class="bi bi-pc-display me-1"></i><span class="ip-count"><?= (int)$g['total_ips'] ?></span>
                                </button>
                            </td>
                            <td class="text-end">
                                <button class="btn btn-sm btn-outline-danger"
                                        onclick="removerGrupo(<?= $g['id'] ?>, '<?= h($g['nome']) ?>')">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Criar Grupo -->
<div class="modal fade" id="modalGrupo" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Novo Grupo</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="formGrupo">
                <?= csrf_field() ?>
                <div class="modal-body">
                    <div id="erroGrupo" class="alert alert-danger d-none"></div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Nome</label>
                        <input type="text" name="nome" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Tipo de acesso</label>
                        <select name="tipo" class="form-select" required>
                            <option value="">Selecione...</option>
                            <option value="bloqueado">Bloqueado</option>
                            <option value="parcial">Parcial</option>
                            <option value="liberado">Liberado (sem proxy, sem registro)</option>
                            <option value="isento">Isento de login (passa pelo proxy, com registro)</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Descrição</label>
                        <textarea name="descricao" class="form-control" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal IPs -->
<div class="modal fade" id="modalIps" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tituloModalIps">IPs do Grupo</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="formIp" class="row g-2 mb-3 align-items-end">
                    <?= csrf_field() ?>
                    <input type="hidden" name="grupo_id" id="ipGrupoId">
                    <div class="col-md-4"><label class="form-label small">IP ou rede</label><input type="text" name="endereco" class="form-control form-control-sm" placeholder="192.168.1.10" required></div>
                    <div class="col-md-3"><label class="form-label small">Descrição</label><input type="text" name="descricao" class="form-control form-control-sm" placeholder="Opcional"></div>
                    <fieldset class="col-md-3">
                        <legend class="form-label small">Expiração opcional</legend>
                        <div class="input-group input-group-sm">
                            <input id="ipExpiraData" class="form-control" type="text" inputmode="numeric" maxlength="10" placeholder="DD/MM/AAAA" aria-label="Data de expiração">
                            <button id="ipAbrirCalendario" class="btn btn-outline-secondary" type="button" aria-label="Abrir calendário" title="Abrir calendário" hidden><i class="bi bi-calendar3" aria-hidden="true"></i></button>
                        </div>
                        <input id="ipExpiraCalendario" type="date" aria-label="Escolher data de expiração" class="form-control form-control-sm mt-1">
                        <input id="ipExpiraHora" class="form-control form-control-sm mt-1" type="text" inputmode="numeric" maxlength="5" placeholder="HH:MM" aria-label="Hora de expiração em formato de 24 horas">
                    </fieldset>
                    <div class="col-md-2"><button type="submit" class="btn btn-sm btn-primary text-nowrap w-100">
                        <i class="bi bi-plus-lg"></i> Adicionar
                    </button></div>
                </form>
                <div id="erroIp" class="alert alert-danger d-none small"></div>
                <div id="listaIps"></div>
            </div>
        </div>
    </div>
</div>

<script>
const csrf = document.querySelector('meta[name="csrf-token"]').content;
const escaparHtml = valor => String(valor ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

document.getElementById('formGrupo').addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const res = await fetch('/grupos', { method: 'POST', body: fd });
    const data = await res.json();
    if (data.erro) {
        document.getElementById('erroGrupo').textContent = data.erro;
        document.getElementById('erroGrupo').classList.remove('d-none');
    } else {
        recarregarPainel();
    }
});

async function removerGrupo(id, nome) {
    if (!confirm(`Remover grupo "${nome}" e todos os seus IPs?`)) return;
    const fd = new FormData();
    fd.append('_csrf', csrf);
    fd.append('_method', 'DELETE');
    const res = await fetch('/grupos/' + id, { method: 'POST', body: fd });
    const data = await res.json();
    if (data.erro) { alert(data.erro); } else { recarregarPainel(); }
}

async function verIps(id, nome) {
    document.getElementById('tituloModalIps').textContent = 'IPs — ' + nome;
    document.getElementById('ipGrupoId').value = id;
    await carregarIps(id);
    new bootstrap.Modal(document.getElementById('modalIps')).show();
}

const podeAlterarEstado = <?= pode_editar() ? 'true' : 'false' ?>;

async function carregarIps(id) {
    const res = await fetch('/grupos/' + id + '/ips');
    const data = await res.json();
    const lista = document.getElementById('listaIps');
    if (!data.ips || data.ips.length === 0) {
        lista.innerHTML = '<p class="text-muted small">Nenhum IP cadastrado.</p>';
        return;
    }
    lista.innerHTML = '<table class="table table-sm align-middle"><thead><tr><th>Ativar / desativar</th><th>Status</th><th>IP</th><th>Descrição</th><th></th></tr></thead><tbody>' +
        data.ips.map(ip =>
            `<tr>
              <td><input type="checkbox" class="form-check-input" data-ip-estado="${ip.id}" data-estado="${escaparHtml(ip.estado)}" aria-label="Ativar ou desativar ${escaparHtml(ip.endereco)}" ${ip.estado === 'ativo' ? 'checked' : ''} ${podeAlterarEstado ? '' : 'disabled'}></td>
              <td><span class="badge rounded-pill ${ip.estado === 'ativo' ? 'bg-success' : 'bg-secondary'}">${escaparHtml(ip.estado)}</span></td>
              <td><span class="font-monospace fw-semibold text-primary">${escaparHtml(ip.endereco)}</span></td>
              <td class="text-muted small">${escaparHtml(ip.descricao || '')}${ip.expira_em ? `<div class="text-warning">Expira: ${escaparHtml(ip.expira_em)}</div>` : ''}</td>
              <td class="text-end">
                <button class="btn btn-sm btn-outline-secondary" title="Remover" onclick="removerIp(${ip.id}, '${ip.endereco}', ${id})">
                  <i class="bi bi-trash3"></i>
                </button>
              </td>
            </tr>`
        ).join('') + '</tbody></table>';
}

const expiraData = document.getElementById('ipExpiraData');
const expiraHora = document.getElementById('ipExpiraHora');
const expiraCalendario = document.getElementById('ipExpiraCalendario');
const abrirCalendario = document.getElementById('ipAbrirCalendario');

function mascararCampo(campo, separador, tamanhos) {
    campo.addEventListener('input', () => {
        const inicio = campo.selectionStart;
        const digitosAntes = campo.value.slice(0, inicio).replace(/\D/g, '').length;
        const digitos = campo.value.replace(/\D/g, '');
        let offset = 0;
        campo.value = tamanhos.map(tamanho => {
            const trecho = digitos.slice(offset, offset + tamanho);
            offset += tamanho;
            return trecho;
        }).filter(Boolean).join(separador);
        let posicao = 0;
        let vistos = 0;
        while (posicao < campo.value.length && vistos < digitosAntes) {
            if (/\d/.test(campo.value[posicao])) vistos++;
            posicao++;
        }
        campo.setSelectionRange(posicao, posicao);
    });
}
mascararCampo(expiraData, '/', [2, 2, 4]);
mascararCampo(expiraHora, ':', [2, 2]);

function dataDigitadaIso(valor) {
    const partes = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(valor);
    if (!partes) return '';
    const [, dia, mes, ano] = partes;
    const iso = ano + '-' + mes + '-' + dia;
    const data = new Date(iso + 'T00:00:00Z');
    return Number.isFinite(data.getTime()) && data.toISOString().slice(0, 10) === iso && ano !== '0000' ? iso : '';
}

expiraCalendario.addEventListener('change', () => {
    expiraData.value = expiraCalendario.value.split('-').reverse().join('/');
});
expiraData.addEventListener('input', () => {
    expiraCalendario.value = dataDigitadaIso(expiraData.value);
});
if (typeof expiraCalendario.showPicker === 'function') {
    expiraCalendario.classList.add('visually-hidden');
    expiraCalendario.tabIndex = -1;
    abrirCalendario.hidden = false;
    abrirCalendario.addEventListener('click', () => {
        try {
            expiraCalendario.showPicker();
        } catch {
            expiraCalendario.classList.remove('visually-hidden');
            expiraCalendario.removeAttribute('tabindex');
            expiraCalendario.focus();
        }
    });
}

document.getElementById('formIp').addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const erroEl = document.getElementById('erroIp');
    if (expiraData.value || expiraHora.value) {
        const dataIso = dataDigitadaIso(expiraData.value);
        const horaValida = /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(expiraHora.value);
        if (!dataIso || !horaValida) {
            erroEl.textContent = 'Informe uma data válida (DD/MM/AAAA) e uma hora de 00:00 a 23:59.';
            erroEl.classList.remove('d-none');
            (dataIso ? expiraHora : expiraData).focus();
            return;
        }
        fd.set('expira_em', dataIso + 'T' + expiraHora.value);
    }
    const gid = document.getElementById('ipGrupoId').value;
    const res = await fetch('/grupos/' + gid + '/ips', { method: 'POST', body: fd });
    const data = await res.json();
    if (data.erro) {
        erroEl.classList.remove('alert-info');
        erroEl.classList.add('alert-danger');
        erroEl.textContent = data.erro;
        erroEl.classList.remove('d-none');
    } else {
        erroEl.classList.add('d-none');
        e.target.reset();
        document.getElementById('ipGrupoId').value = gid;
        await carregarIps(gid);
        atualizarContador(gid);
    }
});

document.getElementById('listaIps').addEventListener('change', async evento => {
    const campo = evento.target.closest('[data-ip-estado]');
    if (!campo) return;
    const ativar = campo.checked;
    const gid = document.getElementById('ipGrupoId').value;
    const aviso = document.getElementById('erroIp');
    const dados = new FormData();
    dados.set('_csrf', csrf);
    dados.set('ativo', ativar ? '1' : '0');
    aviso.classList.add('d-none');
    campo.disabled = true;

    try {
        if (ativar && campo.dataset.estado === 'expirado') {
            const data = dataDigitadaIso(expiraData.value);
            if (!data || !/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(expiraHora.value)) {
                expiraData.focus();
                throw new Error('Preencha a nova data e hora em Expiração opcional e marque o IP novamente.');
            }
            dados.set('expira_em', data + 'T' + expiraHora.value);
        }
        const resposta = await fetch('/ips/' + campo.dataset.ipEstado + '/estado', {method: 'POST', body: dados});
        const resultado = await resposta.json();
        if (!resposta.ok || !resultado.sucesso) throw new Error(resultado.erro || 'Falha ao atualizar o IP.');
        await carregarIps(gid);
        atualizarContador(gid);
        aviso.textContent = resultado.sucesso;
        aviso.classList.remove('d-none', 'alert-danger');
        aviso.classList.add('alert-info');
    } catch (erro) {
        campo.checked = !ativar;
        aviso.textContent = erro.message || 'Falha ao atualizar o IP.';
        aviso.classList.remove('d-none', 'alert-info');
        aviso.classList.add('alert-danger');
    } finally {
        campo.disabled = false;
    }
});

async function removerIp(id, endereco, grupoId) {
    if (!confirm(`Remover IP ${endereco}?`)) return;
    const fd = new FormData();
    fd.append('_csrf', csrf);
    fd.append('_method', 'DELETE');
    const res = await fetch('/ips/' + id, { method: 'POST', body: fd });
    const data = await res.json();
    if (data.erro) { alert(data.erro); } else {
        await carregarIps(grupoId);
        atualizarContador(grupoId);
    }
}

async function atualizarContador(gid) {
    const res = await fetch('/grupos/' + gid + '/ips');
    const data = await res.json();
    const btn = document.getElementById('btn-ips-' + gid);
    if (btn) btn.querySelector('.ip-count').textContent = data.ips ? data.ips.length : 0;
}

async function aplicarNftables() {
    if (!confirm('Reaplicar regras nftables agora?')) return;
    const fd = new FormData();
    fd.append('_csrf', csrf);
    const res = await fetch('/grupos/aplicar', { method: 'POST', body: fd });
    const data = await res.json();
    alert(data.sucesso || data.erro);
}
</script>
