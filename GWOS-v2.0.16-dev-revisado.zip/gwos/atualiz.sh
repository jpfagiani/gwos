#!/bin/bash
# GWOS — atualiz.sh: procura no servidor os arquivos mais novos do GWOS e aplica.
#
#   bash atualiz.sh              # procura e lista os pacotes
#   bash atualiz.sh --listar     # só mostra o que achou (não altera nada)
#   bash atualiz.sh --sim /caminho  # aplica a origem indicada sem perguntar
#   bash atualiz.sh /caminho     # usa este ZIP ou esta pasta
#   bash atualiz.sh --simular /caminho  # mostra os arquivos que seriam trocados
#   bash atualiz.sh --dir /opt/gwos   # onde o GWOS está instalado (detecta sozinho)
#
# Onde procura (até 4 níveis): dentro da própria pasta do GWOS (inclui atualizacao/ e
# novo/), a pasta acima dela, /root, /home, /srv, /tmp, /mnt e /media. Reconhece:
#   • ZIP completo           GWOS*.zip
#   • pasta completa         descompactada (tem app/, modulos/ e config/config.php)
#   • arquivos soltos        pasta atualizacao/ ou novo/ com só alguns arquivos, no mesmo
#                            caminho relativo (ex.: atualizacao/app/Core/Monitoramento.php)
# Arquivos soltos são sobrepostos a uma cópia da instalação atual; o resultado passa
# por scripts/atualizar.sh (backup, sintaxe, migrations, módulos, reversão se falhar).
set -Eeuo pipefail

R='\033[0;31m'; G='\033[0;32m'; Y='\033[1;33m'; B='\033[1m'; N='\033[0m'
ok()   { echo -e "${G}[OK]${N} $*"; }
info() { echo -e "${Y}[..]${N} $*"; }
falha(){ echo -e "${R}[ERRO]${N} $*" >&2; }

DESTINO=""; ORIGEM=""; LISTAR=0; SIM=0; SIMULAR=0
while [ $# -gt 0 ]; do
    case "$1" in
        --dir) [ "$#" -ge 2 ] || { falha "--dir exige um caminho."; exit 2; }; DESTINO="$2"; shift 2 ;;
        --listar) LISTAR=1; shift ;;
        --sim) SIM=1; shift ;;
        --simular) SIMULAR=1; shift ;;
        -h|--help) sed -n 2,19p "$0"; exit 0 ;;
        -*) falha "Opção desconhecida: $1"; exit 2 ;;
        *) ORIGEM="$1"; shift ;;
    esac
done
[ "$(id -u)" -eq 0 ] || { falha "Execute como root (sudo bash $0)."; exit 2; }

AQUI="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd)"

# ── Onde o GWOS está instalado ──────────────────────────────────────────
if [ -z "$DESTINO" ]; then
    if [ -f "$AQUI/.env" ] && [ -d "$AQUI/app" ]; then DESTINO="$AQUI"
    elif [ -f "$AQUI/../.env" ] && [ -d "$AQUI/../app" ]; then DESTINO="$(cd "$AQUI/.." && pwd)"
    elif [ -L /usr/local/bin/gwos ]; then DESTINO="$(cd "$(dirname "$(readlink -f /usr/local/bin/gwos)")/.." && pwd)"
    else for d in /opt/gwos /opt/dns /srv/gwos "$HOME/gwos"; do [ -f "$d/.env" ] && [ -d "$d/app" ] && { DESTINO="$d"; break; }; done
    fi
fi
[ -n "$DESTINO" ] && [ -d "$DESTINO/app" ] || { falha "Instalação do GWOS não encontrada. Use --dir /caminho."; exit 1; }
DESTINO="$(cd "$DESTINO" && pwd)"
versao_de() { sed -n "s/.*'versao' *=> *'\([^']*\)'.*/\1/p" | head -1; }
VERSAO_ATUAL="$(versao_de < "$DESTINO/config/config.php" 2>/dev/null || true)"
info "Instalação: ${B}${DESTINO}${N}  (versão ${VERSAO_ATUAL:-?})"

RSYNC_EX=(--exclude .env --exclude 'storage/' --exclude 'docs/capturas/' --exclude '.git/')
command -v rsync >/dev/null || { falha "Instale rsync para comparar pacotes."; exit 1; }
command -v unzip >/dev/null || { falha "Instale unzip para verificar pacotes ZIP."; exit 1; }

# ── Procura ─────────────────────────────────────────────────────────────
declare -a C_TIPO=() C_PATH=() C_VER=() C_TS=() C_DIF=()
add() { C_TIPO+=("$1"); C_PATH+=("$2"); C_VER+=("$3"); C_TS+=("$4"); C_DIF+=("$5"); }

dif_dir() { rsync -ani "${RSYNC_EX[@]}" "$1/" "$DESTINO/" 2>/dev/null | grep -c '^>f' || true; }

if [ -z "$ORIGEM" ]; then LISTAR=1; fi

if [ -n "$ORIGEM" ]; then
    LISTA_ZIP=(); LISTA_DIR=()
    [ -e "$ORIGEM" ] || { falha "Não encontrei: $ORIGEM"; exit 1; }
    if [ -f "$ORIGEM" ]; then LISTA_ZIP=("$ORIGEM"); else LISTA_DIR=("$ORIGEM"); fi
else
    RAIZES=("$DESTINO" "$(dirname "$DESTINO")" /root /home /srv /tmp /mnt /media)
    mapfile -t LISTA_ZIP < <(for r in "${RAIZES[@]}"; do [ -d "$r" ] && find "$r" -maxdepth 4 -type f -iname 'GWOS*.zip' -not -path '*/var/lib/gwos/*' 2>/dev/null; done | sort -u)
    mapfile -t LISTA_DIR < <(
        { for r in "${RAIZES[@]}"; do [ -d "$r" ] && find "$r" -maxdepth 5 -type f -path '*/config/config.php' -not -path '*/storage/*' -not -path '/var/lib/gwos/*' 2>/dev/null | sed 's#/config/config.php$##'; done
          for r in "$DESTINO" /root /home /srv /tmp; do [ -d "$r" ] && find "$r" -maxdepth 3 -type d \( -name atualizacao -o -name novo -o -name gwos-novo -o -name update \) -not -path '/var/lib/gwos/*' 2>/dev/null; done
        } | while read -r d; do [ -d "$d" ] && [ "$(readlink -f "$d")" != "$DESTINO" ] && readlink -f "$d"; done | sort -u)
fi

for z in "${LISTA_ZIP[@]:-}"; do
    [ -n "$z" ] && [ -f "$z" ] || continue
    unzip -tq "$z" >/dev/null 2>&1 || continue
    cfg="$(unzip -Z1 "$z" 2>/dev/null | grep -m1 'config/config.php$' || true)"
    [ -n "$cfg" ] || continue
    v="$(unzip -p "$z" "$cfg" 2>/dev/null | versao_de || true)"
    add zip "$(readlink -f "$z")" "${v:-?}" "$(stat -c %Y "$z")" "—"
done
for d in "${LISTA_DIR[@]:-}"; do
    [ -n "$d" ] && [ -d "$d" ] || continue
    d="$(readlink -f "$d")"
    [ "$d" != "$DESTINO" ] || continue
    case "$d" in "$DESTINO"/storage*|/var/lib/gwos/*|/proc/*|/sys/*) continue;; esac
    ts="$(find "$d" -type f -not -path '*/.git/*' -printf '%T@\n' 2>/dev/null | sort -n | tail -1 | cut -d. -f1)"
    [ -n "$ts" ] || continue
    if [ -f "$d/config/config.php" ] && [ -d "$d/app" ] && [ -d "$d/modulos" ]; then
        add pasta "$d" "$(versao_de < "$d/config/config.php" || echo '?')" "$ts" "$(dif_dir "$d")"
    elif [ -d "$d/app" ] || [ -d "$d/scripts" ] || [ -d "$d/modulos" ] || [ -d "$d/public" ] || [ -d "$d/database" ] || [ -d "$d/routes" ] || [ -d "$d/config" ]; then
        add soltos "$d" "—" "$ts" "$(dif_dir "$d")"
    fi
done

[ "${#C_TIPO[@]}" -gt 0 ] || {
    falha "Não achei nenhum pacote ou arquivo novo."
    echo "  Coloque o ZIP (GWOS*.zip) ou os arquivos em ${DESTINO}/atualizacao/ (mesmos caminhos: app/..., scripts/...) e rode de novo."
    exit 1; }

# ── Ordena: versão maior primeiro, depois o mais recente ─────────────────
ORDEM=$(for i in "${!C_TIPO[@]}"; do v="${C_VER[$i]}"; [[ "$v" =~ ^[0-9] ]] || v="${VERSAO_ATUAL:-0}"; printf '%s\t%s\t%s\n' "$v" "${C_TS[$i]}" "$i"; done | sort -t$'\t' -k1,1Vr -k2,2nr | cut -f3)
echo ""
echo -e "${B} #  tipo    versão          modificado        arquivos diferentes  caminho${N}"
n=0; declare -a IDX
for i in $ORDEM; do
    n=$((n+1)); IDX[$n]=$i
    v="${C_VER[$i]}"; rot=""
    if [[ "$v" =~ ^[0-9] ]]; then
        if [ "$v" = "$VERSAO_ATUAL" ]; then rot=" (igual)"; elif [ "$(printf '%s\n%s\n' "$v" "$VERSAO_ATUAL" | sort -V | head -1)" = "$v" ]; then rot=" (mais antiga)"; else rot=" (NOVA)"; fi
    fi
    printf ' %-2s %-7s %-15s %-17s %-20s %s\n' "$n" "${C_TIPO[$i]}" "${v}${rot}" "$(date -d @"${C_TS[$i]}" '+%d/%m %H:%M')" "${C_DIF[$i]}" "${C_PATH[$i]}"
done
echo ""
if [ "$LISTAR" -eq 1 ]; then
    info "Para aplicar, informe explicitamente o caminho de um pacote confiável."
    exit 0
fi

I="${IDX[1]}"; TIPO="${C_TIPO[$I]}"; CAM="${C_PATH[$I]}"
info "Escolhido: ${B}${TIPO}${N} ${CAM}"

# ── Aplica ──────────────────────────────────────────────────────────────
TMP="$(mktemp -d /tmp/gwos-atualiz.XXXXXX)"; trap 'rm -rf "$TMP"' EXIT
ARGS=(--dir "$DESTINO"); [ "$SIM" -eq 1 ] && ARGS+=(--sim); [ "$SIMULAR" -eq 1 ] && ARGS+=(--simular)
SCRIPT_NOVO=""
case "$TIPO" in
    zip)
        z_atz="$(unzip -Z1 "$CAM" | grep -m1 'scripts/atualizar.sh$' || true)"
        [ -n "$z_atz" ] && { unzip -p "$CAM" "$z_atz" > "$TMP/atualizar.sh"; SCRIPT_NOVO="$TMP/atualizar.sh"; }
        ORIGEM_FINAL="$CAM" ;;
    pasta)
        [ -f "$CAM/scripts/atualizar.sh" ] && SCRIPT_NOVO="$CAM/scripts/atualizar.sh"
        ORIGEM_FINAL="$CAM" ;;
    soltos)
        info "Arquivos soltos: sobrepondo à cópia da instalação atual..."
        mkdir -p "$TMP/pacote"
        rsync -a "${RSYNC_EX[@]}" "$DESTINO/" "$TMP/pacote/"
        rsync -a "${RSYNC_EX[@]}" "$CAM/" "$TMP/pacote/"
        [ -f "$CAM/scripts/atualizar.sh" ] && SCRIPT_NOVO="$CAM/scripts/atualizar.sh"
        ORIGEM_FINAL="$TMP/pacote" ;;
esac
# Usa o atualizador do pacote novo (mais recente); senão, o instalado
[ -n "$SCRIPT_NOVO" ] || SCRIPT_NOVO="$DESTINO/scripts/atualizar.sh"
[ -f "$SCRIPT_NOVO" ] || { falha "scripts/atualizar.sh não encontrado."; exit 1; }
cp "$SCRIPT_NOVO" "$TMP/atualizar_run.sh"
set +e
bash "$TMP/atualizar_run.sh" "${ARGS[@]}" "$ORIGEM_FINAL"
rc=$?
exit $rc
