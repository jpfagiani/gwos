<?php
$titulo = 'Equipamentos';
$modulo = 'equipamentos';
$podeEditarEquipamentos = pode_editar();
?>
<header class="gw-pagina-cabecalho">
    <h1>Equipamentos</h1>
    <span class="gw-total-itens"><?= count($equipamentos) ?> no inventário</span>
</header>

<div class="card gw-equipamentos-painel">
    <?php if ($podeEditarEquipamentos && $equipamentos): ?>
        <div class="gw-equipamentos-barra d-flex flex-wrap gap-2 align-items-center">
            <label class="me-auto"><input type="checkbox" id="selTodos" class="form-check-input me-2">Selecionar todos</label>
            <span class="small text-muted" role="status"><span id="qtdSel">0</span> selecionado(s)</span>
            <button type="button" class="btn btn-sm btn-outline-primary" data-gw-acao="alterar_grupo" data-gw-selecao=".sel-eq" disabled>Alterar grupo</button>
            <button type="button" class="btn btn-sm btn-outline-primary" data-gw-acao="liberar_temporario" data-gw-selecao=".sel-eq" disabled>Liberar temporariamente</button>
            <button type="button" class="btn btn-sm btn-outline-danger" data-gw-acao="bloquear" data-gw-selecao=".sel-eq" disabled>Bloquear</button>
        </div>
    <?php endif; ?>
    <div class="table-responsive" tabindex="0" role="region" aria-label="Inventário de equipamentos">
        <table class="table align-middle mb-0 gw-tabela-cartoes gw-inventario" role="table">
            <thead class="table-light" role="rowgroup"><tr role="row">
                <th scope="col" role="columnheader">Equipamento</th>
                <th scope="col" role="columnheader">Política e sessão</th>
                <th scope="col" role="columnheader">Tráfego HTTP · 24 h</th>
                <th scope="col" role="columnheader">Último acesso</th>
                <th scope="col" role="columnheader">Ações</th>
            </tr></thead>
            <tbody role="rowgroup">
            <?php foreach ($equipamentos as $e):
                $urlIp = rawurlencode($e['ip']);
                $ultimo = !empty($e['ultimo_acesso']) ? strtotime($e['ultimo_acesso']) : false;
                $origens = ['sessao' => 'Sessão', 'dhcp' => 'DHCP', 'arp' => 'ARP', 'squid' => 'Squid'];
            ?>
                <tr role="row">
                    <td role="cell" class="gw-inventario-identidade">
                        <div class="gw-inventario-dispositivo">
                            <?php if ($podeEditarEquipamentos): ?>
                                <input type="checkbox" class="form-check-input sel-eq" value="<?= h($e['ip']) ?>" aria-label="Selecionar <?= h($e['ip']) ?>">
                            <?php endif; ?>
                            <div class="gw-inventario-dados">
                                <a class="font-monospace fw-bold" href="/equipamentos/ficha?ip=<?= $urlIp ?>"><?= h($e['ip']) ?></a>
                                <div class="small text-muted">Origem <?= h($origens[$e['origem']] ?? $e['origem']) ?></div>
                                <?php if (!empty($e['hostname'])): ?><div><?= h($e['hostname']) ?></div><?php endif; ?>
                                <?php if (!empty($e['mac'])): ?><small class="text-muted font-monospace"><?= h($e['mac']) ?></small><?php endif; ?>
                            </div>
                        </div>
                    </td>
                    <td role="cell" data-rotulo="Política e sessão">
                        <strong><?= h($e['grupo_nome'] ?? 'Sem regra') ?></strong>
                        <div class="small text-muted"><?= h($e['email'] ?? 'Sem sessão ativa') ?></div>
                        <?php if ($e['expira_em']): ?><div class="small">Expira em <?= h($e['expira_em']) ?></div><?php endif; ?>
                    </td>
                    <td role="cell" data-rotulo="Tráfego HTTP · 24 h">
                        <dl class="gw-inventario-trafego">
                            <dt>Requisições</dt><dd><?= number_format((int) $e['requisicoes'], 0, ',', '.') ?></dd>
                            <dt>Download</dt><dd><?= h(formatar_bytes((int) $e['download_24h'])) ?></dd>
                            <dt>Upload</dt><dd><?= $e['upload_24h'] === null ? 'Sem dados' : h(formatar_bytes((int) $e['upload_24h'])) ?></dd>
                        </dl>
                    </td>
                    <td role="cell" data-rotulo="Último acesso">
                        <?php if ($ultimo !== false): ?>
                            <time datetime="<?= h(date('c', $ultimo)) ?>"><?= h(date('d/m/Y', $ultimo)) ?><br><small><?= h(date('H:i:s', $ultimo)) ?></small></time>
                        <?php else: ?>Sem registro<?php endif; ?>
                    </td>
                    <td role="cell" data-rotulo="Ações">
                        <details class="gw-inventario-acoes">
                            <summary class="btn btn-sm btn-outline-primary">Ações <span class="visually-hidden">para <?= h($e['ip']) ?></span><i class="bi bi-chevron-down ms-1" aria-hidden="true"></i></summary>
                            <div>
                                <a class="btn btn-sm btn-outline-primary" href="/equipamentos/ficha?ip=<?= $urlIp ?>">Ficha</a>
                                <a class="btn btn-sm btn-outline-secondary" href="/internet/logs?ip=<?= $urlIp ?>">Histórico</a>
                                <?php if (!empty($e['email'])): ?><a class="btn btn-sm btn-outline-secondary" href="/internet">Usuários e sessões</a><?php endif; ?>
                                <?php if ($podeEditarEquipamentos): ?>
                                    <button type="button" class="btn btn-sm btn-outline-primary" data-gw-acao="liberar_temporario" data-gw-ips="<?= h($e['ip']) ?>">Liberar temporariamente</button>
                                    <button type="button" class="btn btn-sm btn-outline-danger" data-gw-acao="bloquear" data-gw-ips="<?= h($e['ip']) ?>">Bloquear</button>
                                <?php endif; ?>
                            </div>
                        </details>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$equipamentos): ?>
                <tr role="row"><td role="cell" colspan="5" class="text-center text-muted py-4">Nenhum equipamento observado. O inventário é preenchido a partir do Squid, do DHCP e dos vizinhos da LAN.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<script>
(() => {
    const painel = document.querySelector('.gw-equipamentos-painel');
    const todos = painel.querySelector('#selTodos');
    if (!todos) return;
    const total = painel.querySelector('#qtdSel');
    const caixas = [...painel.querySelectorAll('.sel-eq')];
    const botoes = painel.querySelectorAll('[data-gw-selecao]');

    function atualizarSelecao() {
        const selecionados = caixas.filter(caixa => caixa.checked).length;
        total.textContent = selecionados;
        todos.checked = selecionados === caixas.length;
        todos.indeterminate = selecionados > 0 && selecionados < caixas.length;
        botoes.forEach(botao => { botao.disabled = selecionados === 0; });
    }

    todos.addEventListener('change', () => {
        caixas.forEach(caixa => { caixa.checked = todos.checked; });
        atualizarSelecao();
    });
    caixas.forEach(caixa => caixa.addEventListener('change', atualizarSelecao));
    atualizarSelecao();
})();
</script>
