<?php $titulo = 'Primeiro acesso'; require __DIR__ . '/_topo.php'; ?>
<?php if (!empty($direto)): ?>
<p class="small text-muted">Crie seu login: informe seu nome, seu e-mail <strong>@<?= h($dominio) ?></strong> e uma senha.
   Depois é só entrar para liberar a internet.</p>
<?php else: ?>
<p class="small text-muted">Informe seu nome e seu e-mail <strong>@<?= h($dominio) ?></strong>.
   Enviaremos um link para você confirmar o e-mail e criar sua senha.</p>
<?php endif; ?>
<form method="POST" action="/acesso/cadastro" autocomplete="off">
    <?= csrf_field() ?>
    <div class="mb-3">
        <label class="form-label small fw-semibold">Nome completo</label>
        <input type="text" name="nome" class="form-control" maxlength="100" required autofocus autocomplete="name">
    </div>
    <div class="mb-3">
        <label class="form-label small fw-semibold">E-mail institucional</label>
        <input type="email" name="email" class="form-control" placeholder="nome@<?= h($dominio) ?>" required autocomplete="email">
    </div>
    <?php if (!empty($direto)): ?>
    <div class="mb-3">
        <label class="form-label small fw-semibold">Senha</label>
        <input type="password" name="senha" class="form-control" required minlength="8" maxlength="72" autocomplete="new-password">
        <div class="form-text">Mínimo 8 caracteres, com letras e números.</div>
    </div>
    <div class="mb-3">
        <label class="form-label small fw-semibold">Confirmar senha</label>
        <input type="password" name="confirmar" class="form-control" required minlength="8" maxlength="72" autocomplete="new-password">
    </div>
    <button class="btn btn-primary w-100">Criar meu login</button>
    <?php else: ?>
    <button class="btn btn-primary w-100">Enviar link de confirmação</button>
    <?php endif; ?>
</form>
<p class="small mt-3 mb-0"><a href="/acesso">&larr; Voltar</a></p>
<?php require __DIR__ . '/_fim.php'; ?>
